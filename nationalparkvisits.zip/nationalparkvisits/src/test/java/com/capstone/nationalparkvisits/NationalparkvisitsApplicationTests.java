package com.capstone.nationalparkvisits;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NationalparkvisitsApplicationTests {

	@Test
	void contextLoads() {
	}

}
