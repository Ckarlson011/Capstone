package com.capstone.nationalparkvisits;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NationalparkvisitsApplication {

	public static void main(String[] args) {
		SpringApplication.run(NationalparkvisitsApplication.class, args);
	}

}
